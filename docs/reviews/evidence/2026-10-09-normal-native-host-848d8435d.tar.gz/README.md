# Local Native Host evidence

Executed source: `848d8435dc52c773281dd8da385a9f925d26f905`.
`accepted` contains unmodified comparison/evaluation originals, settings, raw
streams, synthetic input DBs, boundary receipts and independent analysis.
`guards` fixes producer, runtime and consumer results. The release witness fixes
generated C and binary bytes; binaries/build trees are regenerable and omitted.
Exact invocation paths are recorded as executed and are machine-specific.
`commands` preserves the bounded local protocol and helper commands; this is
not a new product CLI. All fixtures are synthetic/local; no service write or CI.

Readback at the submitted repository can use
`compareWholeNativeProfiles(extracted + '/accepted/text/comparison',
extracted + '/accepted/text/evaluation')` from the existing
`benchmarks/retained-results/whole-run-comparison.mjs` (and similarly JOIN).
It validates original streams, independent result/schema expectations, every
current request/snapshot/selection/attempt correspondence and held-out costs.
It does not execute Native or relabel old revisions.

Earlier preparation and evaluation failures remain separate originals. Failed
or missing slots were not replaced. The corrected revision used the same finite
plan and new originals. No old profile was promoted to a new runtime revision.
The library component #1027 requires the connection fixes in #1031.
