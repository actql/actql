import assert from 'node:assert/strict';
import {readFile,writeFile} from 'node:fs/promises';
import {join} from 'node:path';
import {compareWholeNativeProfiles} from 'file:///Users/t14i/workspace/20260822/worktrees/actql-local-native-performance-profile/benchmarks/retained-results/whole-run-comparison.mjs';
const base='/private/tmp/actql-g-normal-host-848d8435d',analyses={};
for(const name of ['text','join']) {
 analyses[name]=await compareWholeNativeProfiles(join(base,name,'comparison'),join(base,name,'evaluation'));
 console.log(JSON.stringify({name,chosen:analyses[name].chosenPosition,medians:Object.fromEntries(Object.entries(analyses[name].groups).map(([k,v])=>[k,v.callerElapsedMs.median])),value:analyses[name].value}));
}
const normal=JSON.parse(await readFile(join(base,'text/normal-boundaries/receipt.json'))),shared=JSON.parse(await readFile(join(base,'text/shared-boundaries/acceptance.json')));
assert.equal(normal.receipts.length,12);assert(normal.receipts.every(r=>r.accepted));
await writeFile(join(base,'independent-analysis.json'),JSON.stringify({analyses,normal,shared},null,2)+'\n');
