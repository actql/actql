import {mkdir,readFile,writeFile} from 'node:fs/promises';
import {pathToFileURL} from 'node:url';
import {join} from 'node:path';
import {execFile} from 'node:child_process';
import {promisify} from 'node:util';
const root=process.cwd(),base='/private/tmp/actql-g-normal-host-d3a020519/text';
const {retainedCase,workloads}=await import(pathToFileURL(join(root,'benchmarks/retained-results/fixtures.mjs')));
const {prepareNativeDirectProduct,executeNativeDirectProduct,admitNativeDirectProduct}=await import(pathToFileURL(join(root,'benchmarks/retained-results/native-direct-product.mjs')));
const fixture=retainedCase(workloads[2],'text-1024',1000);
for(const arm of ['unconfigured-control','configured-backtrace']) {
 const dir=join(base,arm);await mkdir(dir,{mode:0o700});
 const invocation=await prepareNativeDirectProduct({root,fixture,database:join(base,'source.duckdb'),directory:dir,residentPolicy:true,attemptCap:12,phaseObserver:true});
 if(arm==='unconfigured-control') {
  try{const observed=await executeNativeDirectProduct(invocation,{root,timeoutMs:30000});await writeFile(join(dir,'stdout.log'),observed.stdout);admitNativeDirectProduct(fixture,invocation,observed);console.log('unconfigured Native control: Result and release accepted');}
  catch(e){await writeFile(join(dir,'stdout.log'),e.stdout??'');await writeFile(join(dir,'stderr.log'),e.stderr??'');throw e;}
 } else {
  await writeFile(join(dir,'normal-settings.json'),await readFile(join(base,'exposure/normal-settings.json')));
  const result=await promisify(execFile)('/usr/bin/lldb',['--batch','-o','settings set target.disable-aslr false','-o','run','-o','thread backtrace all','--',invocation.binary,...invocation.arguments],{cwd:root,env:{...process.env,ACTQL_NATIVE_HOST_PROFILE_SETTINGS:'normal-settings.json'},timeout:30000,maxBuffer:2*1024*1024});
  await writeFile(join(dir,'lldb.log'),result.stdout+'\n'+result.stderr);console.log(result.stdout.slice(-12000));
 }
}
