import {runLocalCheck} from '/Users/t14i/workspace/20260822/worktrees/actql-local-native-performance-profile/scripts/local-checks-guard.mjs';
const root='/Users/t14i/workspace/20260822/worktrees/actql-local-native-performance-profile';
process.exitCode=await runLocalCheck({root,heavy:false,timeoutSeconds:120,graceSeconds:5,steps:[{name:'Independent normal Host original and held-out comparison',command:process.execPath,args:['/private/tmp/actql-g-normal-host-readback.mjs']}]});
