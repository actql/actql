import assert from 'node:assert/strict';
import {readFile,writeFile} from 'node:fs/promises';
import {execFileSync} from 'node:child_process';
import {pathToFileURL} from 'node:url';
import {join} from 'node:path';
const root=process.cwd(),git=args=>execFileSync('git',args,{encoding:'utf8',maxBuffer:4*1024*1024}).trim();
const revision=git(['rev-parse','HEAD']);assert.equal(git(['status','--porcelain']),'');
const {sha256File}=await import(pathToFileURL(join(root,'benchmarks/retained-results/release-artifacts.mjs')));
const {profileDigest}=await import(pathToFileURL(join(root,'benchmarks/retained-results/local-performance-profile.mjs')));
const producer=JSON.parse(await readFile(join(root,'_build/local-checks/attempts/run-J9FoCo/summary.json'),'utf8'));
assert.equal(producer.exitCode,0);assert.equal(producer.complete,true);assert.equal(producer.locksReleased,true);
assert(producer.steps.every(s=>s.status==='passed'));
const witness={revision,compiledRevision:revision,compiledInputsDigest:profileDigest(git(['ls-tree','-r','HEAD','--','src','moon.mod.json','moon.lock','toolchain.json'])),
  binaryDigest:'sha256:'+await sha256File(join(root,'_build/native/release/build/cmd/native_retained_case_probe/native_retained_case_probe.exe')),
  generatedCDigest:'sha256:'+await sha256File(join(root,'_build/native/release/build/cmd/native_retained_case_probe/native_retained_case_probe.c')),
  exitCode:0,producerGuard:'run-J9FoCo',producer,toolchain:JSON.parse(await readFile('toolchain.json','utf8')),
  command:['moon','build','--target','native','--release','src/cmd/native_retained_case_probe','--deny-warn'],
  trust:'guarded clean fixed-source local Native release; not an Actions original'};
await writeFile(join(root,'_build/local-whole-native-build.json'),JSON.stringify(witness,null,2)+'\n',{mode:0o600});
console.log(JSON.stringify({revision,binaryDigest:witness.binaryDigest,generatedCDigest:witness.generatedCDigest}));
