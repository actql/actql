import assert from 'node:assert/strict';
import {mkdir,writeFile,readFile} from 'node:fs/promises';
import {execFile,execFileSync} from 'node:child_process';
import {promisify} from 'node:util';
import {pathToFileURL} from 'node:url';
import {join} from 'node:path';
import {performance} from 'node:perf_hooks';
import {cpus,release} from 'node:os';
const root=process.cwd(),base=process.argv[2];assert(base.startsWith('/private/tmp/actql-g-normal-host-'));
const load=p=>import(pathToFileURL(join(root,'benchmarks/retained-results',p)));
const {retainedCase,workloads}=await load('fixtures.mjs');
const {prepareNativeDirectProduct,executeNativeDirectProduct,admitNativeDirectProduct}=await load('native-direct-product.mjs');
const {sha256File}=await load('release-artifacts.mjs');
const {profileDigest}=await load('local-performance-profile.mjs');
const {wholeRunScope}=await load('whole-run-profile.mjs');
const revision=execFileSync('git',['rev-parse','HEAD'],{encoding:'utf8'}).trim();
assert.equal(execFileSync('git',['status','--porcelain'],{encoding:'utf8'}).trim(),'');
const witness=JSON.parse(await readFile(join(root,'_build/local-whole-native-build.json'),'utf8'));
assert.equal(witness.revision,revision);assert.equal(witness.exitCode,0);
await mkdir(base,{mode:0o700});
for(const [name,fixture,controls] of [
  ['text',retainedCase(workloads[2],'text-1024',1000),{residentPolicy:true,attemptCap:12}],
  ['join',retainedCase(workloads[1],'narrow',100),{residentPolicy:true,attemptCap:4}],
]) {
  const dir=join(base,name);await mkdir(dir,{mode:0o700});const database=join(dir,'source.duckdb');
  const preparation=performance.now();
  await promisify(execFile)(process.execPath,[join(root,'adapters/connectors/duckdb/node/bench/create-retained-source.mjs'),database,fixture.workload,fixture.layout,String(fixture.rows)],{cwd:root,timeout:30000});
  const fixturePreparationMs=performance.now()-preparation;
  const exposure=join(dir,'exposure');await mkdir(exposure,{mode:0o700});
  const invocation=await prepareNativeDirectProduct({root,fixture,database,directory:exposure,...controls,phaseObserver:true});
  assert.equal('sha256:'+await sha256File(invocation.binary),witness.binaryDigest);
  const library=invocation.arguments[invocation.arguments.indexOf('--duckdb-library')+1];
  const environment={platform:process.platform,arch:process.arch,osRelease:release(),cpuModels:[...new Set(cpus().map(c=>c.model))],logicalCpus:cpus().length,
    node:process.version,competingLoad:'uncontrolled',osCache:'uncontrolled',memoryPressure:'unknown',libraryDigest:'sha256:'+await sha256File(library)};
  const instrumentation=profileDigest(await Promise.all(['run-whole-native-profile.mjs','whole-run-profile.mjs','native-direct-product.mjs','native-owner-observations.mjs','native-physical-phases.mjs'].map(async p=>[p,await sha256File(join(root,'benchmarks/retained-results',p))])));
  const settings={mode:'diagnostic-reference',runtime_revision:revision,artifact_digest:witness.binaryDigest,
    environment_digest:profileDigest(environment),control_digest:profileDigest(controls),instrumentation_revision:instrumentation,
    measurement_scope_revision:profileDigest(wholeRunScope),capture_mode:'metadata-only',process_state:'new-process-and-environment',
    authorized_scope:'local-synthetic-fixture-only; no export/sharing',realization:'resident',concurrency:1,allow_uncontrolled_load:true,
    profile_file:'-',profile_digest:'-',profile_revision:'-',profile_creation_ms:null,sqlite_library:'/usr/lib/libsqlite3.dylib'};
  await writeFile(join(exposure,'normal-settings.json'),JSON.stringify(settings),{flag:'wx',mode:0o600});
  let observed;
  try {observed=await executeNativeDirectProduct({...invocation,environment:{ACTQL_NATIVE_HOST_PROFILE_SETTINGS:'normal-settings.json'}},{root,timeoutMs:fixture.limits.timeoutMs});}
  catch(error) {await writeFile(join(exposure,'failed-stdout.log'),error.stdout??'',{flag:'wx',mode:0o600});await writeFile(join(exposure,'failed-stderr.log'),error.stderr??'',{flag:'wx',mode:0o600});throw error;}
  await writeFile(join(exposure,'stdout.log'),observed.stdout,{flag:'wx',mode:0o600});
  await writeFile(join(exposure,'stderr.log'),observed.stderr,{flag:'wx',mode:0o600});
  const product=admitNativeDirectProduct(fixture,invocation,observed),body=product.ownerCorrespondence.observations.candidates[0].body;
  assert(body[5].length>1&&body[5].length<=18);
  assert.deepEqual(observed.resultSchemaFields,name==='join'?['n','present']:fixture.fields);
  const line=observed.stdout.split('\n').find(l=>l.startsWith('normal-host-conditions:'));assert(line);
  const conditions=JSON.parse(line.slice('normal-host-conditions:'.length));
  assert.equal(conditions.runtimeRevision,revision);assert.equal(conditions.binaryDigest,witness.binaryDigest);
  assert.equal(conditions.inputRows,fixture.rows);assert.notEqual(conditions.inputDigest,'sha256:'+await sha256File(database),'InputMustBeLogicalIdentity');
  const decisions=observed.stdout.split('\n').filter(l=>l.startsWith('normal-host-decision:')).map(l=>JSON.parse(l.slice('normal-host-decision:'.length)));
  assert.equal(decisions.length,invocation.finalTask);assert(decisions.every(d=>d.selected_position===null&&d.reason==='profile-not-configured'));
  const plan={version:'actql-local-whole-run-plan/0.1',revision,concurrency:1,rounds:3,
    fixture:{workload:fixture.workload,layout:fixture.layout,rows:fixture.rows},database,inputDigest:'sha256:'+await sha256File(database),library,
    controls,candidates:{body,cid:profileDigest(JSON.stringify(body))},fixturePreparationMs,normalHost:{settings,conditions,environment},
    schedule:'comparison every presented candidate, 3 rounds ascending/reverse/ascending; held-out offline/first-use/reuse, reuse/offline/first-use, first-use/reuse/offline',
    termination:'one finite campaign; no refill; no workload/condition adjustment from evaluation; original semantic/resource gates; no CI'};
  await writeFile(join(dir,'plan.json'),JSON.stringify(plan,null,2)+'\n',{flag:'wx',mode:0o600});
  console.log(JSON.stringify({name,positions:body[5].map(a=>a[0]),revision,plan:join(dir,'plan.json'),conditions}));
}
