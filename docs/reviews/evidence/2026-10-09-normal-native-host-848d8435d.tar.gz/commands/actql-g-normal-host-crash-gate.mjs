import {runLocalCheck} from '/Users/t14i/workspace/20260822/worktrees/actql-local-native-performance-profile/scripts/local-checks-guard.mjs';
const root='/Users/t14i/workspace/20260822/worktrees/actql-local-native-performance-profile';
process.exitCode=await runLocalCheck({root,heavy:true,timeoutSeconds:90,graceSeconds:5,steps:[{name:'Native crash control and configured backtrace',command:process.execPath,args:['/private/tmp/actql-g-normal-host-crash-diagnostic.mjs']}]});
