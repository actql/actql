import {runLocalCheck} from '/Users/t14i/workspace/20260822/worktrees/actql-local-native-performance-profile/scripts/local-checks-guard.mjs';
const root='/Users/t14i/workspace/20260822/worktrees/actql-local-native-performance-profile';
process.exitCode=await runLocalCheck({root,heavy:true,timeoutSeconds:60,graceSeconds:5,steps:[{name:'Diagnose captured Source identity boundary',command:process.execPath,args:['/private/tmp/actql-g-normal-host-diagnostic.mjs']}]});
