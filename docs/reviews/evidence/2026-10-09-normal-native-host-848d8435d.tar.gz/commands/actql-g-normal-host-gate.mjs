import {runLocalCheck} from '/Users/t14i/workspace/20260822/worktrees/actql-local-native-performance-profile/scripts/local-checks-guard.mjs';
const root='/Users/t14i/workspace/20260822/worktrees/actql-local-native-performance-profile';
const [stage,base]=process.argv.slice(2);
const stages={prepare:[{name:'Current Native Text/JOIN conditions and candidates',command:process.execPath,args:['/private/tmp/actql-g-normal-host-prepare.mjs',base]}],
comparison:['text','join'].map(name=>({name:`Normal Host ${name} fixed comparison`,command:process.execPath,args:['benchmarks/retained-results/run-whole-native-profile.mjs',`${base}/${name}/comparison`,'comparison',`${base}/${name}/plan.json`]})),
evaluation:['text','join'].map(name=>({name:`Normal Host ${name} held-out evaluation`,command:process.execPath,args:['benchmarks/retained-results/run-whole-native-profile.mjs',`${base}/${name}/evaluation`,'evaluation',`${base}/${name}/plan.json`,`${base}/${name}/comparison`]})),
boundaries:[{name:'Normal Host limited boundary acceptance',command:process.execPath,args:['/private/tmp/actql-g-normal-host-boundaries.mjs',`${base}/text/plan.json`,`${base}/text/comparison`,`${base}/text/normal-boundaries`]}]};
if(!stages[stage])throw Error('unknown stage');
process.exitCode=await runLocalCheck({root,heavy:true,timeoutSeconds:stage==='comparison'?240:180,graceSeconds:5,steps:stages[stage]});
