import {runLocalCheck} from '/Users/t14i/workspace/20260822/worktrees/actql-local-native-performance-profile/scripts/local-checks-guard.mjs';
const root='/Users/t14i/workspace/20260822/worktrees/actql-local-native-performance-profile';
process.exitCode=await runLocalCheck({root,heavy:true,timeoutSeconds:600,graceSeconds:5,steps:[
{name:'Native public caller typecheck',command:'moon',args:['check','--target','native','src/cmd/native_retained_case_probe','--deny-warn']},
{name:'Release ordinary Native Host caller',command:'moon',args:['build','--target','native','--release','src/cmd/native_retained_case_probe','--deny-warn']}
]});
