import {existsSync} from 'node:fs';
import {spawn} from 'node:child_process';
const lock='/Users/t14i/.cache/actql/local-checks/e2bd9c6236a519d4/heavy.lock';
const deadline=Date.now()+1200000;
while(existsSync(lock)) {
  if(Date.now()>=deadline) throw Error('Shared heavy frame was not available within the bounded wait; no lock changed');
  await new Promise(resolve=>setTimeout(resolve,2000));
}
console.log('Shared frame appears free; the existing guard must still acquire it atomically.');
const child=spawn(process.execPath,['/private/tmp/actql-g-normal-host-runtime-all.mjs','/private/tmp/actql-g-normal-host-848d8435d'],{stdio:'inherit',env:process.env});
process.exitCode=await new Promise((resolve,reject)=>{child.on('error',reject);child.on('exit',(code,signal)=>resolve(signal?1:code));});
