import assert from 'node:assert/strict';
import {mkdir,readFile,writeFile} from 'node:fs/promises';
import {execFile} from 'node:child_process';
import {promisify} from 'node:util';
import {pathToFileURL} from 'node:url';
import {join} from 'node:path';
import {performance} from 'node:perf_hooks';
const root=process.cwd(),[planArg,profileArg,destination]=process.argv.slice(2);
const load=p=>import(pathToFileURL(join(root,'benchmarks/retained-results',p)));
const {retainedCase}=await load('fixtures.mjs');
const {profileDigest}=await load('local-performance-profile.mjs');
const {loadWholeRunProfile,wholeRunTemplate,admitWholeRunTrajectory}=await load('whole-run-profile.mjs');
const {prepareNativeDirectProduct,readNativeDirectProductExecution,executeNativeDirectProduct,admitNativeDirectProduct}=await load('native-direct-product.mjs');
const {nativeOwnerObservations}=await load('native-owner-observations.mjs');
const plan=JSON.parse(await readFile(planArg,'utf8')),profile=await loadWholeRunProfile(profileArg);
assert.equal(profile.report.stage,'comparison');assert(profile.report.accepted);assert.equal(profile.report.revision,plan.revision);
const fixture=retainedCase(plan.fixture.workload,plan.fixture.layout,plan.fixture.rows);
const candidates={cid:plan.candidates.cid,canonical_json:JSON.stringify(plan.candidates.body)};
const unknown=e=>({...e,status:'unknown',reason:'quantity-unobserved',median_ms:null,minimum_ms:null,maximum_ms:null});
const schedule=['diagnostic','load-not-permitted','all-unknown','partial-unknown','conditions-mismatch','stale','missing','tampered-pin','single-candidate','stop','cleanup','restart'];
await mkdir(destination,{mode:0o700});const receipts=[];let selectedRequest;
for(const boundary of schedule) {
  const directory=join(destination,boundary);await mkdir(directory,{mode:0o700});
  let invocation=await prepareNativeDirectProduct({root,fixture,database:plan.database,directory,...plan.controls,phaseObserver:true,
    ...(boundary==='stop'?{stopAfterTask:1}:{}),...(boundary==='single-candidate'?{residentPolicy:false}:{}),
  });
  let template=wholeRunTemplate({profile,conditions:profile.report.conditions,candidates,now:Date.now()});
  let settings={...plan.normalHost.settings,mode:boundary==='diagnostic'?'diagnostic-reference':'select-reference',
    allow_uncontrolled_load:boundary!=='load-not-permitted',profile_file:'normal-template.json',profile_revision:profile.profileRevision,
    profile_creation_ms:null};
  if(boundary==='single-candidate') {
    settings.control_digest=profileDigest({...plan.controls,residentPolicy:false});settings.realization='fresh';
    const exposure={...settings,mode:'diagnostic-reference',profile_file:'-'};
    await writeFile(join(directory,'normal-exposure-settings.json'),JSON.stringify(exposure),{flag:'wx',mode:0o600});
    const exposed=await executeNativeDirectProduct({...invocation,environment:{ACTQL_NATIVE_HOST_PROFILE_SETTINGS:'normal-exposure-settings.json'}},{root,timeoutMs:fixture.limits.timeoutMs});
    await writeFile(join(directory,'exposure-stdout.log'),exposed.stdout,{flag:'wx',mode:0o600});
    const product=admitNativeDirectProduct(fixture,invocation,exposed),body=product.ownerCorrespondence.observations.candidates[0].body;
    assert.equal(body[5].length,1);
    const line=exposed.stdout.split('\n').find(l=>l.startsWith('normal-host-conditions:'));assert(line);
    template={...template,candidate_snapshot_cid:profileDigest(JSON.stringify(body)),conditions:JSON.parse(line.slice('normal-host-conditions:'.length)),
      entries:[{position:body[5][0][0],task:1,quantity:'run-caller-elapsed',status:'unknown',reason:'quantity-unobserved',
        median_ms:null,minimum_ms:null,maximum_ms:null,sample_count:0}]};
  }
  if(boundary==='all-unknown') template.entries=template.entries.map(unknown);
  if(boundary==='partial-unknown') {assert(template.entries.length>1);template.entries[0]=unknown(template.entries[0]);}
  if(boundary==='conditions-mismatch') template.conditions={...template.conditions,inputDigest:'functional-other-input'};
  if(boundary==='stale') template={...template,oldest_ms:'0',newest_ms:'0'};
  if(boundary==='missing') settings.profile_file='missing-profile.json';
  const bytes=JSON.stringify(template);
  if(boundary!=='missing') await writeFile(join(directory,'normal-template.json'),bytes,{flag:'wx',mode:0o600});
  settings.profile_digest=boundary==='tampered-pin'?'0'.repeat(64):profileDigest(bytes).slice(7);
  await writeFile(join(directory,'normal-settings.json'),JSON.stringify(settings),{flag:'wx',mode:0o600});
  invocation={...invocation,environment:{ACTQL_NATIVE_HOST_PROFILE_SETTINGS:'normal-settings.json'},
    arguments:[...invocation.arguments,...(boundary==='cleanup'?['--diagnostic-cleanup-failure','true']:[])]};
  const started=performance.now();let streams,failed=false;
  try { streams=await promisify(execFile)(invocation.binary,invocation.arguments,{cwd:root,
    env:{...process.env,...invocation.environment},timeout:fixture.limits.timeoutMs,maxBuffer:2*1024*1024}); }
  catch(error) { failed=true;streams={stdout:error.stdout??'',stderr:error.stderr??''};if(boundary!=='tampered-pin') {await writeFile(join(directory,'failed-stdout.log'),streams.stdout,{flag:'wx',mode:0o600});await writeFile(join(directory,'failed-stderr.log'),streams.stderr,{flag:'wx',mode:0o600});throw error;} }
  const elapsedMs=performance.now()-started;
  await writeFile(join(directory,'stdout.log'),streams.stdout,{flag:'wx',mode:0o600});
  await writeFile(join(directory,'stderr.log'),streams.stderr,{flag:'wx',mode:0o600});
  const observations=nativeOwnerObservations(streams.stdout),decisions=streams.stdout.split('\n').filter(l=>l.startsWith('normal-host-decision:')).map(l=>JSON.parse(l.slice(21)));
  const usage=observations.owners.at(-1);
  if(boundary==='tampered-pin') {
    assert(failed,'InvalidProfilePinAccepted');assert.equal(observations.choices.length,0);
    assert(usage);assert.equal(usage.attempts,0);
    for(const key of ['heldBytes','reservedExecutionBytes','reservedRetentionBytes','reservedTransferBytes','uncertainTransferBytes']) assert.equal(usage[key],0);
  } else if(boundary==='stop') {
    assert(!failed);assert.deepEqual(JSON.parse(streams.stdout.trim().split('\n').at(-1)),{status:'stopped-between-tasks',completed_tasks:1});
    const [held,closed,twice]=observations.owners.slice(-3);assert(held.heldBytes>0);assert.equal(closed.attempts,held.attempts);assert.equal(closed.holdings,held.holdings);assert.deepEqual(twice,{...closed,boundary:'duplicate-close'});assert(streams.stdout.includes('normal-host-stop-retains-responsibility:1'));
    assert.equal(observations.choices.length,1);assert.equal(decisions.length,1);assert.notEqual(decisions[0].selected_position,null);
    for(const key of ['heldBytes','reservedExecutionBytes','reservedRetentionBytes','reservedTransferBytes','uncertainTransferBytes']) assert.equal(usage[key],0);
  } else {
    assert(!failed);let admittedStream=streams.stdout;
    if(boundary==='cleanup') {
      const failedCleanup=observations.owners.find(o=>o.boundary==='failed-cleanup');assert(failedCleanup&&failedCleanup.heldBytes>0);
      assert(streams.stdout.includes('whole-run-cleanup-retry-confirmed'));
      const lines=streams.stdout.split('\n'),i=lines.findIndex(l=>l.startsWith('owner-observation:')&&JSON.parse(l.slice(18)).boundary==='failed-cleanup');
      assert(lines[i+1].startsWith('observer-elapsed-us:'));lines.splice(i,2);admittedStream=lines.join('\n');
    }
    const execution=readNativeDirectProductExecution(invocation,{...streams,stdout:admittedStream,processCycleMs:elapsedMs});
    const product=admitNativeDirectProduct(fixture,invocation,execution,{cleanupRetry:boundary==='cleanup'});
    assert.deepEqual(execution.resultSchemaFields,fixture.fields);assert.equal(decisions.length,invocation.finalTask);
    assert(decisions.slice(1).every(d=>d.reused_profile&&d.costs.first_load_and_validation_microseconds===0));
    if(['cleanup','restart'].includes(boundary)) {
      const trajectory=admitWholeRunTrajectory({stdout:streams.stdout},product);
      if(boundary==='cleanup') selectedRequest=trajectory.requests[0];
      else {assert(selectedRequest);assert.notEqual(trajectory.requests[0].run_identity,selectedRequest.run_identity,'RestartReusedRunIdentity');
        assert.notEqual(trajectory.requests[0].request_id,selectedRequest.request_id,'RestartReusedRequestIdentity');}
    } else {
      assert(product.ownerCorrespondence.observations.choices.every(c=>['OfflineLatency','BoundedLatency'].includes(c.source)));
      assert(decisions.every(d=>d.selected_position===null));
      const expected={diagnostic:'run-caller-elapsed-median','load-not-permitted':'uncontrolled-load-not-permitted',
        'all-unknown':'incomplete-reference','partial-unknown':'incomplete-reference','conditions-mismatch':'conditions-mismatch',
        stale:'freshness-insufficient',missing:'profile-unavailable','single-candidate':'single-candidate'}[boundary];
      assert.equal(decisions[0].reason,expected);
    }
  }
  receipts.push({boundary,accepted:true,source:plan.revision,binaryDigest:profile.report.binaryDigest,
    profileOriginal:profile.profileRevision,templateDigest:profileDigest(bytes),settingsDigest:profileDigest(settings),
    outcome:boundary==='tampered-pin'?'refused':boundary==='stop'?'physically-stopped-between-tasks':'result-and-release-confirmed',
    elapsedMs,decisions,choices:observations.choices,owners:observations.owners,
    stdoutDigest:profileDigest(streams.stdout),stderrDigest:profileDigest(streams.stderr)});
  await writeFile(join(destination,'receipt.json'),JSON.stringify({version:'actql-normal-native-boundaries/0.1',schedule,receipts},null,2)+'\n',{mode:0o600});
  console.log(JSON.stringify({boundary,accepted:true,elapsedMs}));
}
