import {runLocalCheck} from '/Users/t14i/workspace/20260822/worktrees/actql-local-native-performance-profile/scripts/local-checks-guard.mjs';
const root='/Users/t14i/workspace/20260822/worktrees/actql-local-native-performance-profile',base=process.argv[2];
if(!base?.startsWith('/private/tmp/actql-g-normal-host-'))throw Error('Owned destination required');
const step=(name,args)=>({name,command:process.execPath,args});
process.exitCode=await runLocalCheck({root,heavy:true,timeoutSeconds:360,graceSeconds:5,steps:[
step('Fixed release source and artifact witness',['/private/tmp/actql-g-normal-host-witness.mjs']),
step('Actual Native Host Source and candidates',['/private/tmp/actql-g-normal-host-prepare.mjs',base]),
...['text','join'].map(name=>step(`Fixed ${name} comparison`,['benchmarks/retained-results/run-whole-native-profile.mjs',`${base}/${name}/comparison`,'comparison',`${base}/${name}/plan.json`])),
...['text','join'].map(name=>step(`Held-out ${name} normal Host evaluation`,['benchmarks/retained-results/run-whole-native-profile.mjs',`${base}/${name}/evaluation`,'evaluation',`${base}/${name}/plan.json`,`${base}/${name}/comparison`])),
step('Twelve ordinary Host functional boundaries',['/private/tmp/actql-g-normal-host-boundaries.mjs',`${base}/text/plan.json`,`${base}/text/comparison`,`${base}/text/normal-boundaries`]),
step('Shared current request admission negatives',['benchmarks/retained-results/run-whole-native-boundaries.mjs',`${base}/text/plan.json`,`${base}/text/comparison`,`${base}/text/shared-boundaries`,'binding,expiry']),
]});
