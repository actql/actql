import {mkdir,readFile,writeFile} from 'node:fs/promises';
import {pathToFileURL} from 'node:url';
import {join} from 'node:path';
const root=process.cwd(),prior='/private/tmp/actql-g-normal-host-795dd58ae/text',dir='/private/tmp/actql-g-normal-host-source-diagnostic';
const {retainedCase,workloads}=await import(pathToFileURL(join(root,'benchmarks/retained-results/fixtures.mjs')));
const {prepareNativeDirectProduct,executeNativeDirectProduct}=await import(pathToFileURL(join(root,'benchmarks/retained-results/native-direct-product.mjs')));
await mkdir(dir,{mode:0o700});
await writeFile(join(dir,'normal-settings.json'),await readFile(join(prior,'exposure/normal-settings.json')));
const invocation=await prepareNativeDirectProduct({root,fixture:retainedCase(workloads[2],'text-1024',1000),database:join(prior,'source.duckdb'),directory:dir,residentPolicy:true,attemptCap:12,phaseObserver:true});
try{const observed=await executeNativeDirectProduct({...invocation,environment:{ACTQL_NATIVE_HOST_PROFILE_SETTINGS:'normal-settings.json'}},{root,timeoutMs:30000});console.log(observed.stdout);}catch(e){await writeFile(join(dir,'failure-stdout.log'),e.stdout??'');await writeFile(join(dir,'failure-stderr.log'),e.stderr??'');console.log(e.stdout,e.stderr);throw e;}
