import assert from 'node:assert/strict';
import {execFileSync} from 'node:child_process';
import {runLocalCheck} from '/Users/t14i/workspace/20260822/worktrees/actql-local-native-performance-profile/scripts/local-checks-guard.mjs';
assert.equal(execFileSync('git',['rev-parse','HEAD'],{encoding:'utf8'}).trim(),'4cf4a3eae6fe3caa336dbfecbc086345c68929f7');
assert.equal(execFileSync('git',['status','--porcelain'],{encoding:'utf8'}).trim(),'');
assert.deepEqual(execFileSync('git',['diff','--name-only','b51af198e7d15b977998c38a3815f657ba7a7b57','HEAD'],{encoding:'utf8'}).trim().split('\n'),['benchmarks/retained-results/empirical-comparison.mjs']);
process.exitCode=await runLocalCheck({root:process.cwd(),heavy:false,timeoutSeconds:180,graceSeconds:5,steps:[
{name:'P3 corrected independent readback over immutable b51af198e Native originals',command:process.execPath,args:['/private/tmp/g-p3-compare-readback.mjs','/private/tmp/g-p3-comparison-b51af198e-20261008','/private/tmp/g-p3-evaluation-b51af198e-20261008']}
]});
