import {runLocalCheck,lockDirectory} from '/Users/t14i/workspace/20260822/worktrees/actql-local-native-performance-profile/scripts/local-checks-guard.mjs';
import {existsSync,readFileSync} from 'node:fs';
import {join} from 'node:path';
const lock=join(lockDirectory().path,'heavy.lock');
if(existsSync(lock)) {const owner=JSON.parse(readFileSync(lock));throw Error('Existing heavy owner '+owner.pid+' at '+owner.worktree+'; no competing gate or lock removal');}
const comparison='/private/tmp/g-p3-comparison-bbba06a98-20261008';
const evaluation='/private/tmp/g-p3-evaluation-bbba06a98-20261008';
const boundaries='/private/tmp/g-p3-boundaries-bbba06a98-20261008';
process.exitCode=await runLocalCheck({root:process.cwd(),heavy:true,timeoutSeconds:240,graceSeconds:5,steps:[
{name:'P3 fixed six comparison executions',command:process.execPath,args:['benchmarks/retained-results/run-local-native-profile.mjs',comparison,'--empirical-comparison']},
{name:'P3 fixed six held-out evaluation executions',command:process.execPath,args:['benchmarks/retained-results/run-local-native-profile.mjs',evaluation,'--empirical-evaluation',comparison]},
{name:'P3 Native stop and expired-request boundaries',command:process.execPath,args:['benchmarks/retained-results/run-native-empirical-boundaries.mjs',comparison,boundaries]},
{name:'P3 independent held-out readback',command:process.execPath,args:['/private/tmp/g-p3-compare-readback.mjs',comparison,evaluation]}
]});
