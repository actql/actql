import {runLocalCheck,lockDirectory} from '/Users/t14i/workspace/20260822/worktrees/actql-local-native-performance-profile/scripts/local-checks-guard.mjs';
import {existsSync,readFileSync} from 'node:fs';
import {join} from 'node:path';
const root=process.cwd(),m=root+'/.toolchains/moonbit-0.10.12+1634b282e';
const lock=join(lockDirectory().path,'heavy.lock');
if(existsSync(lock)) {const owner=JSON.parse(readFileSync(lock));throw Error('Existing heavy owner '+owner.pid+' at '+owner.worktree+'; no competing gate or lock removal');}
const env={MOON_HOME:m,PATH:m+'/bin:'+process.env.PATH};
const run="import {runFocusedTests} from './scripts/test-execution.mjs'; process.exitCode=runFocusedTests(process.argv[1],process.argv.slice(2),{cwd:process.cwd()});";
process.exitCode=await runLocalCheck({root,heavy:true,timeoutSeconds:1200,graceSeconds:5,steps:[
{name:'P3 fixed-SHA selected JS tests',command:process.execPath,args:['--input-type=module','-e',run,'moon','--target','js','src/physical_strategy/empirical_ranking_wbtest.mbt','src/physical_strategy/operational_estimates_wbtest.mbt','src/query_integration/adaptive_policy_wbtest.mbt'],env},
{name:'P3 fixed-source release build',command:m+'/bin/moon',args:['build','--target','native','--release','src/cmd/native_retained_case_probe','--deny-warn'],env},
{name:'P3 actual build witness',command:process.execPath,args:['/private/tmp/g-p3-build-witness.mjs']}
]});
