import assert from 'node:assert/strict';
import {execFileSync} from 'node:child_process';
import {readFileSync} from 'node:fs';
assert.equal(execFileSync('git',['rev-parse','HEAD'],{encoding:'utf8'}).trim(),'b51af198e7d15b977998c38a3815f657ba7a7b57');
assert.equal(execFileSync('git',['status','--porcelain'],{encoding:'utf8'}).trim(),'');
const previous=JSON.parse(readFileSync('/private/tmp/g-p3-dd4a804fd-actual-build-witness.json'));
assert.notEqual(execFileSync('git',['ls-tree','-r','HEAD','src','moon.mod.json','toolchain.json'],{encoding:'utf8'}),previous.sourceTree);
console.log('Exact patched source verified under exclusive guard; previous measurement source is not reused.');
