import {compareNativeEmpiricalRuns} from '/Users/t14i/workspace/20260822/worktrees/actql-local-native-performance-profile/benchmarks/retained-results/empirical-comparison.mjs';
import {writeFile} from 'node:fs/promises';
import {execFileSync} from 'node:child_process';
const report=await compareNativeEmpiricalRuns(process.argv[2],process.argv[3]);
report.readbackImplementationRevision=execFileSync('git',['rev-parse','HEAD'],{encoding:'utf8'}).trim();
await writeFile('/private/tmp/g-p3-independent-comparison-b51af198e.json',JSON.stringify(report,null,2)+'\n',{flag:'wx',mode:0o600});
console.log(JSON.stringify({chosenPosition:report.chosenPosition,selectionChanged:report.selectionChanged,heldOutProcessingMedianDifferenceMs:report.heldOutProcessingMedianDifferenceMs,groups:Object.fromEntries(Object.entries(report.groups).map(([k,v])=>[k,{taskProcessingMs:v.taskProcessingMs,consultationMs:v.consultationMs,processCycleMs:v.processCycleMs,cleanupMs:v.cleanupMs}]))}));
