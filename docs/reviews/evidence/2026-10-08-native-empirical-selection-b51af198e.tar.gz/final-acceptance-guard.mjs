import {runLocalCheck,lockDirectory} from '/Users/t14i/workspace/20260822/worktrees/actql-local-native-performance-profile/scripts/local-checks-guard.mjs';
import {existsSync,readFileSync} from 'node:fs';
import {join} from 'node:path';
const root=process.cwd(),m=root+'/.toolchains/moonbit-0.10.12+1634b282e';
const lock=join(lockDirectory().path,'heavy.lock');
if(existsSync(lock)) {const owner=JSON.parse(readFileSync(lock));throw Error('Existing heavy owner '+owner.pid+' at '+owner.worktree+'; no competing gate or lock removal');}
const env={MOON_HOME:m,PATH:m+'/bin:'+process.env.PATH};
const comparison='/private/tmp/g-p3-comparison-b51af198e-20261008';
const evaluation='/private/tmp/g-p3-evaluation-b51af198e-20261008';
const boundaries='/private/tmp/g-p3-boundaries-b51af198e-20261008';
process.exitCode=await runLocalCheck({root,heavy:true,timeoutSeconds:360,graceSeconds:5,steps:[
{name:'P3 frozen patched source',command:process.execPath,args:['/private/tmp/g-p3-preflight-source.mjs']},
{name:'P3 fixed-source release build',command:m+'/bin/moon',args:['build','--target','native','--release','src/cmd/native_retained_case_probe','--deny-warn'],env},
{name:'P3 actual build witness',command:process.execPath,args:['/private/tmp/g-p3-build-witness.mjs']},
{name:'P3 fixed six comparison executions',command:process.execPath,args:['benchmarks/retained-results/run-local-native-profile.mjs',comparison,'--empirical-comparison']},
{name:'P3 fixed six held-out evaluation executions',command:process.execPath,args:['benchmarks/retained-results/run-local-native-profile.mjs',evaluation,'--empirical-evaluation',comparison]},
{name:'P3 Native stop and expired-request boundaries',command:process.execPath,args:['benchmarks/retained-results/run-native-empirical-boundaries.mjs',comparison,boundaries]},
{name:'P3 independent held-out readback',command:process.execPath,args:['/private/tmp/g-p3-compare-readback.mjs',comparison,evaluation]}
]});
