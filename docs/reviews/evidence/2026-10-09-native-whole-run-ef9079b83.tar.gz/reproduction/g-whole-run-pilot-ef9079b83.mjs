import assert from 'node:assert/strict';
import {mkdir,readFile,writeFile} from 'node:fs/promises';
import {execFile,execFileSync} from 'node:child_process';
import {promisify} from 'node:util';
import {performance} from 'node:perf_hooks';
import {join} from 'node:path';
import {pathToFileURL} from 'node:url';
const root=process.cwd(),base='/private/tmp/g-whole-run-fixed-ef9079b83';
const revision=execFileSync('git',['rev-parse','HEAD'],{encoding:'utf8'}).trim();
assert.equal(revision,'ef9079b83d119e54b03618056bfd7fb94b7dc4f9');
assert.equal(execFileSync('git',['status','--porcelain'],{encoding:'utf8'}).trim(),'');
await mkdir(base,{mode:0o700});
const commands=[];
const timed=async(name,args)=>{
  const started=performance.now();
  let streams;
  try {streams=await promisify(execFile)(process.execPath,args,{cwd:root,timeout:600000,maxBuffer:4*1024*1024});}
  catch(error) {await writeFile(join(base,name+'-failed-stdout.log'),error.stdout??'',{flag:'wx',mode:0o600});
    await writeFile(join(base,name+'-failed-stderr.log'),error.stderr??'',{flag:'wx',mode:0o600});throw error;}
  const elapsedMs=performance.now()-started;
  await writeFile(join(base,name+'-stdout.log'),streams.stdout,{flag:'wx',mode:0o600});
  await writeFile(join(base,name+'-stderr.log'),streams.stderr,{flag:'wx',mode:0o600});
  commands.push({name,command:[process.execPath,...args],elapsedMs,exitCode:0});
  await writeFile(join(base,'command-costs.json'),JSON.stringify({revision,commands},null,2)+'\n',{mode:0o600});
  console.log(JSON.stringify({name,elapsedMs,accepted:true}));
  return elapsedMs;
};
const load=path=>import(pathToFileURL(join(root,'benchmarks/retained-results',path)));
const {compareWholeNativeProfiles}=await load('whole-run-comparison.mjs');
const {wholeRunValue}=await load('whole-run-profile.mjs');
for(const name of ['text','join']) {
  const directory=join(base,name);
  const preparationMs=await timed(name+'-preparation',['/private/tmp/g-whole-run-prepare-ef9079b83.mjs',name]);
  const comparisonMs=await timed(name+'-comparison',['benchmarks/retained-results/run-whole-native-profile.mjs',directory+'/comparison','comparison',directory+'/plan.json']);
  await timed(name+'-evaluation',['benchmarks/retained-results/run-whole-native-profile.mjs',directory+'/evaluation','evaluation',directory+'/plan.json',directory+'/comparison']);
  const plan=JSON.parse(await readFile(directory+'/plan.json','utf8'));
  const result=await compareWholeNativeProfiles(directory+'/comparison',directory+'/evaluation');
  const creationMs=preparationMs-plan.fixturePreparationMs+comparisonMs;
  assert(creationMs>=0);
  const resultWithCosts={...result,originalDirectCreationValue:result.value,
    costApplication:{revision,comparisonOriginal:result.comparisonOriginal,preparationMs,comparisonMs,
      commonSyntheticDatabasePreparationMs:plan.fixturePreparationMs,profileCreationMs:creationMs,
      scope:'monotonic child-process clocks include candidate exposure, source acquisition, construction, validation, aggregation, record/receipt writes and process exit; synthetic DB population is separate common fixture preparation, subtracted once; build costs are common runtime preparation and separate'},
    value:wholeRunValue({creationMs,firstUseMs:result.groups['first-use'].callerElapsedMs.median,
      offlineMs:result.groups.offline.callerElapsedMs.median,reusedMs:result.groups.reuse.callerElapsedMs.median})};
  const observations=JSON.parse(await readFile(directory+'/evaluation/whole-run.json','utf8')).observations;
  resultWithCosts.directSelectionCosts=[];
  for(const o of observations) {
    const stdout=await readFile(directory+'/evaluation/trial-'+o.index+'/stdout.log','utf8');
    resultWithCosts.directSelectionCosts.push({index:o.index,arm:o.step.arm,profileReadbackMs:o.profileReadbackMs,
      templateMs:o.templateMs,recordingMs:o.recordingMs,checkpointMs:o.checkpointMs,
      consultationIntervalsUs:stdout.split('\n').filter(l=>l.startsWith('empirical-consult-us:')).map(l=>Number(l.slice('empirical-consult-us:'.length))),
      observerIntervalsUs:o.owner.observations.observerMicroseconds,
      scope:'already inside the enclosing caller clock; intervals are not added to it'});
  }
  await writeFile(directory+'/analysis.json',JSON.stringify(resultWithCosts,null,2)+'\n',{flag:'wx',mode:0o600});
  console.log(JSON.stringify({name,chosenPosition:result.chosenPosition,value:resultWithCosts.value,
    firstUseDifferenceMs:result.firstUseDifferenceMs}));
}
await timed('text-boundaries',['benchmarks/retained-results/run-whole-native-boundaries.mjs',base+'/text/plan.json',base+'/text/comparison',base+'/text/boundaries']);
console.log(JSON.stringify({accepted:true,revision,scope:'two finite Native workloads and separate functional boundaries; not hosted CI'}));
