import assert from 'node:assert/strict';
import {mkdir,writeFile,readFile} from 'node:fs/promises';
import {execFile,execFileSync} from 'node:child_process';
import {promisify} from 'node:util';
import {pathToFileURL} from 'node:url';
import {join} from 'node:path';
import {performance} from 'node:perf_hooks';
const root=process.cwd(),base='/private/tmp/g-whole-run-fixed-ef9079b83';
const load=path=>import(pathToFileURL(join(root,'benchmarks/retained-results',path)));
const {retainedCase,workloads}=await load('fixtures.mjs');
const {prepareNativeDirectProduct,executeNativeDirectProduct,admitNativeDirectProduct}=await load('native-direct-product.mjs');
const {sha256File}=await load('release-artifacts.mjs');
const {profileDigest}=await load('local-performance-profile.mjs');
const revision=execFileSync('git',['rev-parse','HEAD'],{encoding:'utf8'}).trim();
assert.equal(revision,'ef9079b83d119e54b03618056bfd7fb94b7dc4f9');
assert.equal(execFileSync('git',['status','--porcelain'],{encoding:'utf8'}).trim(),'');
const witness=JSON.parse(await readFile(join(root,'_build/local-whole-native-build.json'),'utf8'));
assert.equal(witness.revision,revision);assert.equal(witness.exitCode,0);
const requested=process.argv[2];assert(['text','join'].includes(requested));
// These conditions are fixed before any comparative timing. The JOIN fixture
// admits only its four normal task attempts, with no extra resident setup/import
// budget. Text retains the existing twelve-attempt limit. Neither changes a
// ceiling or selects a candidate after observing evaluation performance.
for(const [name,fixture,controls] of [
  ['text',retainedCase(workloads[2],'text-1024',1000),{residentPolicy:true,attemptCap:12}],
  ['join',retainedCase(workloads[1],'narrow',100),{residentPolicy:true,attemptCap:4}],
]) {
  if(name!==requested) continue;
  const dir=join(base,name);await mkdir(dir,{mode:0o700});const database=join(dir,'source.duckdb');
  const preparationStart=performance.now();
  await promisify(execFile)(process.execPath,[join(root,'adapters/connectors/duckdb/node/bench/create-retained-source.mjs'),database,fixture.workload,fixture.layout,String(fixture.rows)],{cwd:root,timeout:30000});
  const fixturePreparationMs=performance.now()-preparationStart;
  const exposure=join(dir,'exposure');await mkdir(exposure,{mode:0o700});
  const invocation=await prepareNativeDirectProduct({root,fixture,database,directory:exposure,...controls,phaseObserver:true});
  assert.equal('sha256:'+await sha256File(invocation.binary),witness.binaryDigest);
  const execution=await executeNativeDirectProduct(invocation,{root,timeoutMs:fixture.limits.timeoutMs});
  await writeFile(join(exposure,'stdout.log'),execution.stdout,{flag:'wx',mode:0o600});
  await writeFile(join(exposure,'stderr.log'),execution.stderr,{flag:'wx',mode:0o600});
  const product=admitNativeDirectProduct(fixture,invocation,execution),body=product.ownerCorrespondence.observations.candidates[0].body;
  assert(body[5].length>1&&body[5].length<=18,'FiniteWholeRunCandidateBudget');
  assert.deepEqual(execution.resultSchemaFields,name==='join'?['n','present']:fixture.fields);
  const library=invocation.arguments[invocation.arguments.indexOf('--duckdb-library')+1];
  const plan={version:'actql-local-whole-run-plan/0.1',revision,concurrency:1,rounds:3,
    fixture:{workload:fixture.workload,layout:fixture.layout,rows:fixture.rows},database,inputDigest:'sha256:'+await sha256File(database),
    library,controls,candidates:{body,cid:profileDigest(JSON.stringify(body))},fixturePreparationMs,
    schedule:'comparison: every presented candidate, three rounds ascending/reverse/ascending; evaluation: offline/first-use/reuse, reuse/offline/first-use, first-use/reuse/offline',
    limits:'no full matrix; no refill; no candidate filtering; original common capacity/work bounds; configured attempt budget as declared before comparative timing'};
  await writeFile(join(dir,'plan.json'),JSON.stringify(plan,null,2)+'\n',{flag:'wx',mode:0o600});
  console.log(JSON.stringify({name,positions:body[5].map(a=>a[0]),controls,source:revision,binaryDigest:witness.binaryDigest,plan:join(dir,'plan.json')}));
}
